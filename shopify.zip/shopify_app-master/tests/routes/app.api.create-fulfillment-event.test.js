import { describe, it, expect, vi, beforeEach } from "vitest";
import { action } from "../../app/routes/app.api.create-fulfillment-event"; // Adjust path if needed
import prisma from "../../app/db.server";
import { logger } from "../../app/logger";

const dummyRequest = new Request("http://test.com", {
  method: "POST",
  body: JSON.stringify({
    shop: "example.myshopify.com",
    gid: "gid://shopify/Order/123456",
    status: "IN_TRANSIT",
    message: "Package shipped",
  }),
});

// --- MOCKS ---
vi.mock("../../app/db.server", () => ({
  default: {
    session: { findFirst: vi.fn() },
  },
}));

vi.mock("../../app/logger", () => ({
  logger: { info: vi.fn(), error: vi.fn(), warn: vi.fn() },
}));

vi.stubGlobal("fetch", vi.fn());

// Helper function to easily parse the Response body
const getResponseData = async (response) => {
  const text = await response.text();
  return JSON.parse(text);
};

describe("API Action: Create Fulfillment Event", () => {
  const shop = "test-shop.myshopify.com";
  const gid = "gid://shopify/Order/12345";
  const status = "IN_TRANSIT";
  const message = "Your package is on its way.";
  const validRequestBody = { shop, gid, status, message };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Input Validation", () => {
    it("should return 400 if shop is missing", async () => {
      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify({ gid, status }),
      });

      const response = await action({ request });
      const responseData = await getResponseData(response);

      expect(response.status).toBe(400);
      expect(responseData.success).toBe(false);
      expect(responseData.error.code).toBe("MISSING_FIELDS");
      expect(responseData.error.message).toContain("shop");
    });

    it("should return 400 if gid or status is missing", async () => {
      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify({ shop }),
      });

      const response = await action({ request });
      const responseData = await getResponseData(response);

      expect(response.status).toBe(400);
      expect(responseData.success).toBe(false);
      expect(responseData.error.code).toBe("MISSING_FIELDS");
      expect(responseData.error.message).toContain("gid, status");
    });
  });

  describe("Service & API Failures", () => {
    it("should return 404 if shop session is not found", async () => {
      prisma.session.findFirst.mockResolvedValue(null);
      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });

      const response = await action({ request });
      const responseData = await getResponseData(response);

      expect(response.status).toBe(404);
      expect(responseData.success).toBe(false);
      expect(responseData.error.code).toBe("SESSION_NOT_FOUND");
    });

    it("should return 404 if fetching fulfillments returns GraphQL errors", async () => {
      prisma.session.findFirst.mockResolvedValue({ accessToken: "fake-token" });
      // Mock the first API call to fail
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            errors: [{ message: "Order not found" }],
          }),
        ),
      );

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });

      const response = await action({ request });
      const responseData = await getResponseData(response);

      expect(response.status).toBe(404);
      expect(responseData.success).toBe(false);
      expect(responseData.error.code).toBe("ORDER_NOT_FOUND");
      expect(fetch).toHaveBeenCalledOnce(); // Important: It should stop here
    });

    it("should fallback to generic error message if error.message is undefined", async () => {
      const request = new Request("http://test.com", { method: "POST" });
      // @ts-ignore
      request.json = vi.fn().mockRejectedValue({}); // no message property

      const response = await action({ request });
      const responseData = await getResponseData(response);

      expect(response.status).toBe(500);
      expect(responseData.success).toBe(false);
      expect(responseData.error.message).toBe(
        "An unexpected internal error occurred.",
      );
    });

    it("returns error if fulfillments are missing even when there are no API errors", async () => {
      global.fetch = vi
        .fn()
        // First call: Fetch fulfillments (GraphQL query)
        .mockResolvedValueOnce({
          json: async () => ({
            errors: null,
            data: {
              order: {
                fulfillments: null, // Or omit completely: order: {}
              },
            },
          }),
        });

      const response = await action({ request: dummyRequest });
      const json = await response.json();

      expect(response.status).toBe(404);
      expect(json.success).toBe(false);
      expect(json.error.code).toBe("ORDER_NOT_FOUND");
      expect(json.error.details).toBe("Order or its fulfillments not found.");
    });
  });

  describe("Core Logic & Loop Execution", () => {
    beforeEach(() => {
      // Setup a valid session for all tests in this block
      prisma.session.findFirst.mockResolvedValue({ accessToken: "fake-token" });
    });

    it("should return a success message if order has no fulfillments", async () => {
      // Mock the first API call to return an order with an empty fulfillments array
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: { order: { fulfillments: [] } },
          }),
        ),
      );
      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });

      const response = await action({ request });
      const responseData = await getResponseData(response);

      expect(response.status).toBe(200);
      expect(responseData.success).toBe(true);
      expect(responseData.message).toContain(
        "Order has no fulfillments to update",
      );
      expect(fetch).toHaveBeenCalledOnce();
    });

    it("should successfully create events for all fulfillments (Happy Path)", async () => {
      // Mock GetFulfillments call
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: { order: { fulfillments: [{ id: "ff_1" }, { id: "ff_2" }] } },
          }),
        ),
      );
      // Mock CreateEvent call for ff_1
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              fulfillmentEventCreate: { fulfillmentEvent: { id: "event_1" } },
            },
          }),
        ),
      );
      // Mock CreateEvent call for ff_2
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              fulfillmentEventCreate: { fulfillmentEvent: { id: "event_2" } },
            },
          }),
        ),
      );

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });
      const response = await action({ request });
      const responseData = await getResponseData(response);

      expect(response.status).toBe(200);
      expect(responseData.success).toBe(true);
      expect(responseData.result.successfulEvents).toHaveLength(2);
      expect(responseData.result.failedEvents).toHaveLength(0);
      expect(responseData.message).toContain(
        "All fulfillment events created successfully",
      );
      expect(fetch).toHaveBeenCalledTimes(3); // 1 for get, 2 for create
    });

    it("should handle and log GraphQL top-level errors (eventJson.errors)", async () => {
      prisma.session.findFirst.mockResolvedValue({ accessToken: "fake-token" });

      // Mock getFulfillments response (1 fulfillment)
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: { order: { fulfillments: [{ id: "ff_topErr" }] } },
          }),
        ),
      );

      // Mock event creation with top-level GraphQL errors
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            errors: [{ message: "Some GraphQL error occurred" }],
          }),
        ),
      );

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify({
          shop: "test.myshopify.com",
          gid: "gid://shopify/Order/123",
          status: "IN_TRANSIT",
          message: "Shipped",
        }),
      });

      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(200);
      expect(data.success).toBe(true);
      expect(data.result.successfulEvents).toHaveLength(0);
      expect(data.result.failedEvents).toHaveLength(1);
      expect(data.result.failedEvents[0].fulfillmentId).toBe("ff_topErr");
      expect(data.result.failedEvents[0].errors[0].message).toContain(
        "Some GraphQL error occurred",
      );

      expect(logger.error).toHaveBeenCalledWith(
        expect.stringContaining("GraphQL Error for fulfillment ff_topErr"),
      );
    });

    it("should correctly categorize successful and failed events (Partial Failure)", async () => {
      // Mock GetFulfillments call
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              order: {
                fulfillments: [
                  { id: "ff_1_ok" },
                  { id: "ff_2_fail" },
                  { id: "ff_3_network_error" },
                ],
              },
            },
          }),
        ),
      );
      // Mock CreateEvent for ff_1 (success)
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              fulfillmentEventCreate: { fulfillmentEvent: { id: "event_1" } },
            },
          }),
        ),
      );
      // Mock CreateEvent for ff_2 (GraphQL UserError)
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              fulfillmentEventCreate: {
                userErrors: [{ field: "status", message: "is invalid" }],
              },
            },
          }),
        ),
      );
      // Mock CreateEvent for ff_3 (Network Error)
      fetch.mockRejectedValueOnce(new Error("Request timed out"));

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });
      const response = await action({ request });
      const responseData = await getResponseData(response);

      expect(response.status).toBe(200);
      expect(responseData.success).toBe(true);
      expect(responseData.result.successfulEvents).toHaveLength(1);
      expect(responseData.result.successfulEvents[0].id).toBe("event_1");
      expect(responseData.result.failedEvents).toHaveLength(2);
      expect(responseData.result.failedEvents[0].fulfillmentId).toBe(
        "ff_2_fail",
      );
      expect(responseData.result.failedEvents[1].fulfillmentId).toBe(
        "ff_3_network_error",
      );
      expect(responseData.result.failedEvents[1].errors[0].message).toContain(
        "Network request failed",
      );
      expect(logger.warn).toHaveBeenCalled(); // For the userError
      expect(logger.error).toHaveBeenCalled(); // For the network error
      expect(fetch).toHaveBeenCalledTimes(4); // 1 get, 3 create attempts
    });
  });

  describe("Internal Error Handling", () => {
    it("should return 500 if request.json() fails", async () => {
      const request = new Request("http://test.com", {
        method: "POST",
        body: '{ "this is not valid json" }',
      });
      const response = await action({ request });
      const responseData = await getResponseData(response);

      expect(response.status).toBe(500);
      expect(responseData.success).toBe(false);
      expect(responseData.error.code).toBe("INTERNAL_SERVER_ERROR");
      expect(logger.error).toHaveBeenCalledWith(
        expect.stringContaining("Unhandled Error"),
      );
    });
  });
});
