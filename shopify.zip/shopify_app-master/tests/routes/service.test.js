import { describe, it, expect, vi, beforeEach } from "vitest";
import axios from "axios";
import prisma from "../../app/db.server";
import { logger } from "../../app/logger";
import { formatDate } from "../../app/utils";
import { signin, createOrder } from "../../app/services/API";

// --- MOCKS ---
// Mock the entire axios library
vi.mock("axios");

// Mock prisma client
vi.mock("../../app/db.server", () => ({
  default: {
    user: {
      findFirst: vi.fn(),
      upsert: vi.fn(),
    },
    orders: {
      update: vi.fn(),
    },
  },
}));

// Mock logger
vi.mock("../../app/logger", () => ({
  logger: { info: vi.fn(), error: vi.fn(), warn: vi.fn() },
}));

// Mock utils
vi.mock("../../app/utils", () => ({
  formatDate: vi.fn().mockReturnValue("2023-01-01"),
}));

// --- TEST SUITE ---
describe("API Service", () => {
  beforeEach(() => {
    // Reset all mocks before each test to ensure a clean state
    vi.clearAllMocks();
    // Set a default for axios.post to be overridden in specific tests
    axios.post.mockResolvedValue({ data: {} });
  });

  // --- Tests for the `signin` function ---
  describe("signin function", () => {
    const shop = "test-shop.myshopify.com";

    it("should return an error if no user exists and no credentials are provided", async () => {
      // ARRANGE: Mock prisma to find no user
      prisma.user.findFirst.mockResolvedValue(null);

      // ACT
      const result = await signin(shop);

      // ASSERT
      expect(result.data.status).toBe(false);
      expect(result.data.message).toBe("No user exists for this shop.");
      expect(logger.error).toHaveBeenCalledWith(
        expect.stringContaining("No user exists"),
      );
      expect(axios.post).not.toHaveBeenCalled();
    });

    it("should handle API errors gracefully if axios.post fails", async () => {
      // ARRANGE
      prisma.user.findFirst.mockResolvedValue({
        username: "user",
        password: "pw",
      });
      axios.post.mockRejectedValue(new Error("Network Error"));

      // ACT
      const result = await signin(shop);

      // ASSERT
      expect(result.success).toBe(false);
      expect(result.message).toContain("server error");
      expect(logger.error).toHaveBeenCalledWith(
        expect.stringContaining("API - Sign In -"),
      );
    });

    it("should return an error if the API does not return a token", async () => {
      // ARRANGE
      prisma.user.findFirst.mockResolvedValue({
        username: "user",
        password: "pw",
      });
      axios.post.mockResolvedValue({ data: { status: "failed" } }); // No token

      // ACT
      const result = await signin(shop);

      // ASSERT
      expect(result.data.status).toBe(false);
      expect(result.data.message).toBe("Invalid credentails.");
    });

    it("should successfully sign in and upsert user data with a new token", async () => {
      // ARRANGE
      const fakeToken = "new-auth-token-123";
      prisma.user.findFirst.mockResolvedValue({
        username: "existing_user",
        password: "existing_password",
      });
      axios.post.mockResolvedValue({ data: { token: fakeToken }, status: 200 });
      prisma.user.upsert.mockResolvedValue({ shop, authorized: true });

      // ACT
      const result = await signin(shop);

      // ASSERT
      expect(axios.post).toHaveBeenCalledWith(expect.any(String), {
        username: "existing_user",
        password: "existing_password",
      });
      expect(prisma.user.upsert).toHaveBeenCalledWith({
        where: { shop },
        update: {
          username: "existing_user",
          password: "existing_password",
          token: fakeToken,
          authorized: true,
        },
        create: {
          shop,
          username: "existing_user",
          password: "existing_password",
          token: fakeToken,
          authorized: true,
        },
      });
      expect(result.user).toBeDefined();
      expect(result.result.data.token).toBe(fakeToken);
    });
  });

  // --- Tests for the `createOrder` function ---
  describe("createOrder function", () => {
    const shop = "test-shop.myshopify.com";
    const mockOrder = {
      id: 1,
      order_number: "1001",
      created_at: "2023-01-01T12:00:00Z",
      total_weight: 500,
      line_items: [
        {
          id: 1,
          title: "Test Product",
          quantity: 1,
          price: "10.00",
          sku: "SKU-01",
          tax_lines: [{ title: "IGST", rate: 0.18 }],
        },
      ],
      billing_address: { name: "John Doe", phone: "1234567890" },
      shipping_address: { address1: "123 Main St", zip: "12345" },
      contact_email: "test@example.com",
      financial_status: "paid",
      total_price: "10.00",
      total_outstanding: "0.00",
    };

    it("should return an error if no user is found for the shop", async () => {
      // ARRANGE: No user in the DB
      prisma.user.findFirst.mockResolvedValue(null);

      // ACT
      const result = await createOrder([mockOrder], shop);

      // ASSERT
      expect(result.success).toBe(false);
      expect(result.message).toBe("User Not Found.");
      expect(axios.post).not.toHaveBeenCalled();
    });

    it("should handle a successful order creation", async () => {
      // ARRANGE
      prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
      axios.post.mockResolvedValue({ data: { status_code: 200 } });

      // ACT
      const result = await createOrder([mockOrder], shop);

      // ASSERT
      expect(result.success).toBe(true);
      expect(result.results[0].status).toBe("success");
      expect(prisma.orders.update).toHaveBeenCalledWith({
        where: { id: mockOrder.id.toString() },
        data: { synched: true },
      });
    });

    it("should handle and skip an order that already exists", async () => {
      // ARRANGE
      prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
      axios.post.mockResolvedValue({
        data: {
          status_code: 400,
          data: { message: "Order Already Exist in ERP." },
        },
      });

      // ACT
      const result = await createOrder([mockOrder], shop);

      // ASSERT
      expect(result.success).toBe(true);
      expect(result.results[0].status).toBe("skipped");
      expect(prisma.orders.update).toHaveBeenCalledOnce(); // Still marks as synched
      expect(logger.warn).toHaveBeenCalledWith(
        expect.stringContaining("Skipped order"),
      );
    });

    it("should handle a failed order due to a business logic error (e.g., validation)", async () => {
      // ARRANGE
      prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
      axios.post.mockResolvedValue({
        data: { status_code: 422, data: { message: "Invalid pincode" } },
      });

      // ACT
      const result = await createOrder([mockOrder], shop);

      // ASSERT
      expect(result.success).toBe(false);
      expect(result.results[0].status).toBe("failed");
      expect(result.results[0].message).toBe("Invalid pincode");
      expect(prisma.orders.update).not.toHaveBeenCalled();
      expect(logger.error).toHaveBeenCalledWith(
        expect.stringContaining("Failed to create order"),
      );
    });

    it("should handle a failed order due to a network or server error from axios", async () => {
      // ARRANGE
      prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
      axios.post.mockRejectedValue({
        response: { status: 503, data: "Service Unavailable" },
      });

      // ACT
      const result = await createOrder([mockOrder], shop);

      // ASSERT
      expect(result.success).toBe(false);
      expect(result.results[0].status).toBe("error");
      expect(result.results[0].message).toContain(
        "API request failed with status 503",
      );
      expect(prisma.orders.update).not.toHaveBeenCalled();
      expect(logger.error).toHaveBeenCalledWith(
        expect.stringContaining("API Error for order"),
      );
    });

    it("should correctly handle a mix of successful and failed orders", async () => {
      // ARRANGE
      const order2 = { ...mockOrder, id: 2, order_number: "1002" };
      prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
      // First call succeeds, second call fails
      axios.post
        .mockResolvedValueOnce({ data: { status_code: 200 } })
        .mockRejectedValueOnce({ response: { status: 500 } });

      // ACT
      const result = await createOrder([mockOrder, order2], shop);

      // ASSERT
      expect(result.success).toBe(false); // Overall success is false
      expect(result.results).toHaveLength(2);
      expect(result.results[0].status).toBe("success");

      expect(result.results[1].status).toBe("error");
      expect(prisma.orders.update).toHaveBeenCalledOnce(); // Only for the successful one
    });

    it("should use billing first and last name if full name is not provided", async () => {
      const modifiedOrder = {
        ...mockOrder,
        billing_address: {
          name: undefined,
          first_name: "Jane",
          last_name: "Doe",
          phone: "1234567890",
        },
        shipping_address: { address1: "123 Main St", zip: "12345" },
      };

      prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
      axios.post.mockResolvedValue({ data: { status_code: 200 } });

      await createOrder([modifiedOrder], shop);

      const payloadSent = axios.post.mock.calls[0][1];
      expect(payloadSent["*CUSTOMER_NAME"]).toBe("Jane Doe");
    });

    it("should use shipping first and last name when billing info is missing", async () => {
      const customOrder = {
        ...mockOrder,
        billing_address: undefined, // This is important
        shipping_address: {
          first_name: "Shipping",
          last_name: "Fallback",
          address1: "789 Street",
          zip: "99999",
          city: "CityName",
          province: "StateName",
          country: "CountryName",
          phone: "7777777777",
        },
      };

      prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
      axios.post.mockResolvedValue({ data: { status_code: 200 } });

      await createOrder([customOrder], shop);

      const payloadSent = axios.post.mock.calls[0][1]; // 2nd argument is the payload
      expect(payloadSent["*CUSTOMER_NAME"]).toBe("Shipping Fallback");
    });

    // THIS IS THE NEW TEST TO COVER LINE 124
    it("should use undefined for name when billing and shipping names are incomplete", async () => {
      // ARRANGE: Create an order object where all name checks will fail.
      const orderWithoutFullName = {
        ...mockOrder,
        // 1. No full name, first name, or last name in billing_address
        billing_address: { name: undefined, phone: "1234567890" },
        // 2. Incomplete name (missing last_name) in shipping_address
        shipping_address: {
          first_name: "Incomplete",
          address1: "456 Fallback St",
          zip: "54321",
        },
      };

      prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
      axios.post.mockResolvedValue({ data: { status_code: 200 } });

      // ACT
      await createOrder([orderWithoutFullName], shop);

      // ASSERT
      // Check the payload sent to the API to confirm the name field is undefined.
      const payloadSent = axios.post.mock.calls[0][1];
      expect(payloadSent["*CUSTOMER_NAME"]).toBeUndefined();
    });

     it("should handle a critical synchronous error if prisma fails", async () => {
      // ARRANGE: Mock prisma to throw a critical error before the loop starts
      const dbError = new Error("Database connection failed");
      prisma.user.findFirst.mockRejectedValue(dbError);

      // ACT: Call the function
      const result = await createOrder([mockOrder], shop);

      // ASSERT: The outer catch block should be triggered
      expect(result.success).toBe(false);
      expect(result.message).toBe(
        "Server error, please try again later or contact admin.",
      );

      // Verify that the logger was called with the specific error from the catch block
      expect(logger.error).toHaveBeenCalledWith(
        `A critical error occurred in createOrder function: ${dbError.message}`,
        { stack: expect.any(String) },
      );

      // Ensure the process stopped before attempting any API calls
      expect(axios.post).not.toHaveBeenCalled();
    });

     it("should correctly extract CGST, SGST, and IGST percentages from tax_lines", async () => {
      // ARRANGE: Create an order with all three tax types
      const taxOrder = {
        ...mockOrder,
        id: 123,
        order_number: "2002",
        line_items: [
          {
            id: 1,
            title: "Product with all taxes",
            quantity: 2,
            price: "20.00",
            sku: "SKU-02",
            tax_lines: [
              { title: "IGST", rate: 0.05 },
              { title: "CGST", rate: 0.06 },
              { title: "SGST", rate: 0.07 },
            ],
          },
        ],
      };

      prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
      axios.post.mockResolvedValue({ data: { status_code: 200 } });

      // ACT
      await createOrder([taxOrder], shop);

      // ASSERT: Check that the payload sent to axios contains all correct tax values
      const payloadSent = axios.post.mock.calls[0][1];
      const item = payloadSent["*SHIPMENT_ITEMS"][0];

      expect(item.IGST_PERCENTAGE).toBe(0.05);
      expect(item.CGST_PERCENTAGE).toBe(0.06);
      expect(item.SGST_PERCENTAGE).toBe(0.07);
    });

    it("should fallback to orderData.total_price when line item price is missing", async () => {
      // ARRANGE: Create an order with a line item missing its price
      const fallbackOrder = {
        ...mockOrder,
        id: 125,
        order_number: "2004",
        total_price: "99.99", // This is the value we expect it to fall back to
        line_items: [
          {
            id: 1,
            title: "Product with no price",
            quantity: 1,
            price: undefined, // Explicitly missing price to trigger fallback
            sku: "SKU-04",
            tax_lines: [],
          },
        ],
      };

      prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
      axios.post.mockResolvedValue({ data: { status_code: 200 } });

      // ACT
      await createOrder([fallbackOrder], shop);

      // ASSERT: Check that the item price in the payload is the fallback value
      const payloadSent = axios.post.mock.calls[0][1];
      const item = payloadSent["*SHIPMENT_ITEMS"][0];

      expect(item.ITEM_PRICE).toBe(99.99);
    });

     it("should prioritize contact_email, then customer.email, then order.email", async () => {
        prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
        axios.post.mockResolvedValue({ data: { status_code: 200 } });

        // Case 1: Use contact_email (highest priority)
        const orderWithContactEmail = {
            ...mockOrder,
            contact_email: "contact@email.com",
            customer: { email: "customer@email.com" },
            email: "root@email.com"
        };
        await createOrder([orderWithContactEmail], shop);
        expect(axios.post.mock.calls[0][1]["*CUSTOMER_EMAIL"]).toBe("contact@email.com");

        // Case 2: Fallback to customer.email
        const orderWithCustomerEmail = {
            ...mockOrder,
            contact_email: undefined,
            customer: { email: "customer@email.com" },
            email: "root@email.com"
        };
        await createOrder([orderWithCustomerEmail], shop);
        expect(axios.post.mock.calls[1][1]["*CUSTOMER_EMAIL"]).toBe("customer@email.com");

        // Case 3: Fallback to order.email
        const orderWithRootEmail = {
            ...mockOrder,
            contact_email: undefined,
            customer: undefined,
            email: "root@email.com"
        };
        await createOrder([orderWithRootEmail], shop);
        expect(axios.post.mock.calls[2][1]["*CUSTOMER_EMAIL"]).toBe("root@email.com");
    });

    it("should prioritize billing phone, then shipping phone, then default", async () => {
        prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
        axios.post.mockResolvedValue({ data: { status_code: 200 } });

        // Case 1: Use billing phone (highest priority)
        const orderWithBillingPhone = {
            ...mockOrder,
            billing_address: { phone: "111-222-3333" },
            shipping_address: { phone: "444-555-6666" }
        };
        await createOrder([orderWithBillingPhone], shop);
        expect(axios.post.mock.calls[0][1]["*CUSTOMER_PHONE"]).toBe("111-222-3333");

        // Case 2: Fallback to shipping phone
        const orderWithShippingPhone = {
            ...mockOrder,
            billing_address: { phone: undefined },
            shipping_address: { phone: "444-555-6666" }
        };
        await createOrder([orderWithShippingPhone], shop);
        expect(axios.post.mock.calls[1][1]["*CUSTOMER_PHONE"]).toBe("444-555-6666");

        // Case 3: Fallback to default phone
        const orderWithNoPhone = {
            ...mockOrder,
            billing_address: { phone: undefined },
            shipping_address: { phone: undefined }
        };
        await createOrder([orderWithNoPhone], shop);
        expect(axios.post.mock.calls[2][1]["*CUSTOMER_PHONE"]).toBe("9999999999");
    });

     it("should handle a successful API response that is missing the data property", async () => {
      // ARRANGE
      prisma.user.findFirst.mockResolvedValue({ token: "valid-token" });
      // Mock axios to resolve with a successful status but no 'data' object.
      // This will trigger the `|| {}` fallback on line 157.
      axios.post.mockResolvedValue({ status: 200 /* no data property */ });

      // ACT
      const result = await createOrder([mockOrder], shop);

      // ASSERT
      // The overall operation is considered a failure because the response was unparsable.
      expect(result.success).toBe(false);
      expect(result.results).toHaveLength(1);

      // The status for this specific order is 'failed' because the logic
      // couldn't find a status_code in the empty responseData object.
      expect(result.results[0].status).toBe("failed");
      
      // It should use the fallback error message for this scenario.
      expect(result.results[0].message).toBe("Unknown business logic failure.");
      
      // It should log the failure.
      expect(logger.error).toHaveBeenCalledWith(
        expect.stringContaining("Failed to create order"),
      );
      
      // The database should not be updated since the sync failed.
      expect(prisma.orders.update).not.toHaveBeenCalled();
    });

    it("should handle a critical synchronous error if prisma fails", async () => {
      const dbError = new Error("Database connection failed");
      prisma.user.findFirst.mockRejectedValue(dbError);

      const result = await createOrder([mockOrder], shop);

      expect(result.success).toBe(false);
      expect(result.message).toBe(
        "Server error, please try again later or contact admin.",
      );
    });
  });
});