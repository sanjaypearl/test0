import { describe, it, expect, vi, beforeEach } from "vitest";
import { action } from "../../app/routes/api.get-locations-paginated"; // Adjust the path as needed
import prisma from "../../app/db.server";
import { logger } from "../../app/logger";

// --- MOCKS ---
// Mock the prisma client
vi.mock("../../app/db.server", () => ({
  default: {
    session: {
      findFirst: vi.fn(),
    },
  },
}));

// Mock the logger
vi.mock("../../app/logger", () => ({
  logger: {
    info: vi.fn(),
    error: vi.fn(),
  },
}));

// Mock the global `fetch` function
vi.stubGlobal("fetch", vi.fn());

// --- TEST SUITE ---
describe("API Action: Get Paginated Locations", () => {
  const shop = "test-shop.myshopify.com";

  // Reset mocks before each test to ensure isolation
  beforeEach(() => {
    vi.clearAllMocks();
  });

  // --- Test Scenario: Input Validation ---
  describe("Input Validation", () => {
    it("should return a 400 error if shop is missing", async () => {
      // ARRANGE: Create a request with an empty body
      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify({}), // Missing 'shop'
      });

      // ACT
      const result = await action({ request });
      const json = await result.json();

      expect(result.status).toBe(400);
      expect(json.error).toBe("Shop name is required.");
    });
  });

  // --- Test Scenario: External Service Failures ---
  describe("External Service Failures", () => {
    it("should return a 404 error if shop session is not found", async () => {
      // ARRANGE
      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify({ shop }),
      });
      // Mock prisma to return nothing
      prisma.session.findFirst.mockResolvedValue(null);

      // ACT
      const result = await action({ request });
      const json = await result.json();

      expect(result.status).toBe(404);
      expect(json.error).toBe("Shop session not found.");
      expect(prisma.session.findFirst).toHaveBeenCalledWith({
        where: { shop },
      });
    });

    it("should return an error if the Shopify API returns GraphQL errors", async () => {
      // ARRANGE
      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify({ shop }),
      });
      prisma.session.findFirst.mockResolvedValue({ accessToken: "fake-token" });

      // Mock a Shopify response containing an 'errors' object
      const shopifyErrorResponse = { errors: [{ message: "Invalid query" }] };
      fetch.mockResolvedValue(
        new Response(JSON.stringify(shopifyErrorResponse)),
      );

      // ACT
      const result = await action({ request });

      // ASSERT
      expect(result.error).toBe("Failed to fetch locations");
      expect(result.details).toEqual([{ message: "Invalid query" }]);
      expect(logger.error).toHaveBeenCalled(); // Check that the error was logged
    });
  });

  // --- Test Scenario: Successful Execution ---
  describe("Successful Execution", () => {
    it("should fetch the first page of locations when no cursor is provided", async () => {
      // ARRANGE
      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify({ shop }), // No cursor
      });

      const fakeSession = { accessToken: "fake-token-123" };
      prisma.session.findFirst.mockResolvedValue(fakeSession);

      const fakeShopifyResponse = {
        data: {
          locations: {
            edges: [
              {
                cursor: "cursor-1",
                node: {
                  id: "gid://shopify/Location/1",
                  name: "Warehouse A",
                  isActive: true,
                },
              },
              {
                cursor: "cursor-2",
                node: {
                  id: "gid://shopify/Location/2",
                  name: "Downtown Store",
                  isActive: true,
                },
              },
            ],
            pageInfo: {
              hasNextPage: true,
              endCursor: "cursor-2",
            },
          },
        },
      };
      fetch.mockResolvedValue(
        new Response(JSON.stringify(fakeShopifyResponse)),
      );

      // ACT
      const result = await action({ request });

      // ASSERT
      expect(result.success).toBe(true);
      expect(result.locations).toHaveLength(2);
      expect(result.locations[0].name).toBe("Warehouse A");
      expect(result.pageInfo.hasNextPage).toBe(true);
      expect(result.pageInfo.endCursor).toBe("cursor-2");

      // Check that fetch was called correctly for the first page (cursor is null)
      expect(fetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          body: expect.stringContaining('"cursor":null'),
        }),
      );
    });

    it("should fetch a subsequent page of locations when a cursor is provided", async () => {
      // ARRANGE
      const startCursor = "cursor-abc";
      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify({ shop, cursor: startCursor }),
      });

      prisma.session.findFirst.mockResolvedValue({
        accessToken: "fake-token-123",
      });

      const fakeShopifyResponse = {
        data: {
          locations: {
            edges: [
              {
                cursor: "cursor-def",
                node: {
                  id: "gid://shopify/Location/3",
                  name: "Suburban Outlet",
                  isActive: false,
                },
              },
            ],
            pageInfo: {
              hasNextPage: false,
              endCursor: "cursor-def",
            },
          },
        },
      };
      fetch.mockResolvedValue(
        new Response(JSON.stringify(fakeShopifyResponse)),
      );

      // ACT
      const result = await action({ request });

      // ASSERT
      expect(result.success).toBe(true);
      expect(result.locations).toHaveLength(1);
      expect(result.locations[0].name).toBe("Suburban Outlet");
      expect(result.pageInfo.hasNextPage).toBe(false);

      // Check that fetch was called with the correct cursor
      expect(fetch).toHaveBeenCalledWith(
        `https://${shop}/admin/api/2025-04/graphql.json`,
        expect.objectContaining({
          method: "POST",
          headers: {
            "X-Shopify-Access-Token": "fake-token-123",
            "Content-Type": "application/json",
          },
          body: expect.stringContaining(`"cursor":"${startCursor}"`),
        }),
      );
    });
  });

  // --- Test Scenario: Internal Error Handling ---
  describe("Internal Error Handling", () => {
    it("should return 500 if request.json() throws", async () => {
      const request = new Request("http://test.com", { method: "POST" });
      // @ts-ignore
      request.json = vi.fn().mockRejectedValue(new Error("JSON parse failed"));

      const response = await action({ request });
      const json = await response.json();

      expect(response.status).toBe(500);
      expect(json.success).toBe(false);
      expect(json.error.code).toBe("INTERNAL_SERVER_ERROR");
      expect(json.error.message).toBe("JSON parse failed");
    });

    it("should return 500 and use error.toString() if error.stack is missing", async () => {
      const fakeError = {
        message: "No stack error",
        toString: () => "fallback stringified error",
      };

      const request = new Request("http://test.com", { method: "POST" });
      // @ts-ignore
      request.json = vi.fn().mockRejectedValue(fakeError);

      const response = await action({ request });
      const json = await response.json();

      expect(response.status).toBe(500);
      expect(json.success).toBe(false);
      expect(json.error.code).toBe("INTERNAL_SERVER_ERROR");
      expect(json.error.message).toBe("No stack error");
      expect(json.error.details).toBe("fallback stringified error");
    });

    it("should return 500 with null details if both stack and toString are missing", async () => {
      const fakeError = {
        message: "Bare error",
        // no stack
        toString: undefined, // or not defined at all
      };

      const request = new Request("http://test.com", { method: "POST" });
      // @ts-ignore
      request.json = vi.fn().mockRejectedValue(fakeError);

      const response = await action({ request });
      const json = await response.json();

      expect(response.status).toBe(500);
      expect(json.success).toBe(false);
      expect(json.error.message).toBe("Bare error");
      expect(json.error.details).toBe(null); // <--- the key
    });

    it("should return 500 with fallback message if error.message is undefined", async () => {
  const fakeError = {
    // message missing or undefined
    toString: () => "some string",
  };

  const request = new Request("http://test.com", { method: "POST" });
  // @ts-ignore
  request.json = vi.fn().mockRejectedValue(fakeError);

  const response = await action({ request });
  const json = await response.json();

  expect(response.status).toBe(500);
  expect(json.success).toBe(false);
  expect(json.error.message).toBe("An unknown error occurred.");
});

  });
});
