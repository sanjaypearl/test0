import prisma from "../db.server";
import { logger } from "../logger";

// This is an API endpoint, not a webhook handler.
// Your app will call this endpoint to get a list of locations.
export const action = async ({ request }) => {
  try {
    // The client will send the shop and an optional cursor for pagination.
    const { shop, cursor } = await request.json();

    if (!shop) {
      return new Response(
        JSON.stringify({ success: false, error: "Shop name is required." }),
        { status: 400, headers: { "Content-Type": "application/json" } },
      );
    }

    const session = await prisma.session.findFirst({
      where: { shop: shop },
    });

    if (!session) {
      return new Response(
        JSON.stringify({ success: false, error: "Shop session not found." }),
        { status: 404, headers: { "Content-Type": "application/json" } },
      );
    }

    // This query is designed for pagination.
    // It takes a $cursor variable to know where to start fetching from.
    // It returns 'pageInfo' which tells us if there's a next page and what the next cursor is.
    const GET_LOCATIONS_PAGINATED_QUERY = `
        query getLocationsPaginated($cursor: String) {
            locations(first: 10, after: $cursor) {
                edges {
                    cursor # The cursor for this specific item
                    node {
                        id
                        name
                        isActive
                    }
                }
                pageInfo {
                    hasNextPage
                    endCursor # The cursor to use for the *next* page
                }
            }
        }`;

    const response = await fetch(
      `https://${shop}/admin/api/2025-04/graphql.json`,
      {
        method: "POST",
        headers: {
          "X-Shopify-Access-Token": session.accessToken,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: GET_LOCATIONS_PAGINATED_QUERY,
          variables: {
            // Pass the cursor from the request. If it's the first call, cursor will be null.
            cursor: cursor || null,
          },
        }),
      },
    );

    const data = await response.json();

    if (data.errors) {
      logger.error(
        `Get Paginated Locations Error: ${JSON.stringify(data.errors)}`,
      );
      return { error: "Failed to fetch locations", details: data.errors };
    }

    const locations = data.data.locations.edges.map((edge) => edge.node);
    const pageInfo = data.data.locations.pageInfo;

    // Return the list of locations for the current page, and the pageInfo
    // so the client knows how to fetch the next page.
    return { success: true, locations, pageInfo };
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        error: {
          code: "INTERNAL_SERVER_ERROR",
          message: error?.message || "An unknown error occurred.",
          details: error?.stack || error?.toString?.() || null,
        },
      }),
      { status: 500, headers: { "Content-Type": "application/json" } },
    );
  }
};
