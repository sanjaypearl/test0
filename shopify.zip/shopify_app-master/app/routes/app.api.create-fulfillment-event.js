import { logger } from "../logger";
import prisma from "../db.server";

/**
 * A helper function to create consistent JSON responses.
 * This ensures every API response has the same structure and headers.
 * @param {object} body - The JSON payload for the response.
 * @param {object} options - Standard Response options (e.g., status).
 * @returns {Response}
 */
const createJsonResponse = (body, options) => {
  return new Response(JSON.stringify(body), {
    ...options,
    headers: { "Content-Type": "application/json", ...options?.headers },
  });
};

export const action = async ({ request }) => {
  try {
    const { shop, gid, status, message } = await request.json();

    // 1. Input Validation
    const requiredFields = { shop, gid, status };
    const missingFields = Object.keys(requiredFields).filter(
      (key) => !requiredFields[key],
    );

    if (missingFields.length > 0) {
      const error = {
        code: "MISSING_FIELDS",
        message: `Missing required fields: ${missingFields.join(", ")}`,
        details: missingFields,
      };
      logger.error(`Create Fulfillment Event - Bad Request: ${error.message}`);
      return createJsonResponse({ success: false, error }, { status: 400 });
    }

    // 2. Session Check
    const session = await prisma.session.findFirst({ where: { shop: shop } });

    if (!session) {
      const error = {
        code: "SESSION_NOT_FOUND",
        message: "Shop session not found. Please try reinstalling the app.",
      };
      logger.error(
        `Create Fulfillment Event - Session not found for shop: ${shop}`,
      );
      return createJsonResponse({ success: false, error }, { status: 404 });
    }

    // --- Shopify Logic Begins (Unchanged) ---
    const shopify_api_url = `https://${shop}/admin/api/2025-04/graphql.json`;
    const headers = {
      "X-Shopify-Access-Token": session.accessToken,
      "Content-Type": "application/json",
    };

    const FULFILLMENT_ORDER_QUERY = `
        query GetOrderFulfillments ($orderId:ID!) {
           order(id: $orderId) {
             id
             fulfillments {
               id
               status
               createdAt
             }
           }
         }`;

    const getFulfillmentsResponse = await fetch(shopify_api_url, {
      method: "POST",
      headers,
      body: JSON.stringify({
        query: FULFILLMENT_ORDER_QUERY,
        variables: { orderId: gid },
      }),
    });
    const getFulfillmentsData = await getFulfillmentsResponse.json();

    // 3. GraphQL Response Check
    if (
      getFulfillmentsData.errors ||
      !getFulfillmentsData.data?.order?.fulfillments
    ) {
      const errorDetails =
        getFulfillmentsData.errors || "Order or its fulfillments not found."; // line: 97
      const error = {
        code: "ORDER_NOT_FOUND",
        message: `Could not find fulfillments for order GID: ${gid}`,
        details: errorDetails,
      };
      logger.error(
        `Create Fulfillment Event - Order fetch failed: ${JSON.stringify(errorDetails)}`,
      );
      return createJsonResponse({ success: false, error }, { status: 404 });
    }

    const fulfillments = getFulfillmentsData.data.order.fulfillments;

    // Handle case with no fulfillments
    if (fulfillments.length === 0) {
      return createJsonResponse(
        {
          success: true,
          message: "Order has no fulfillments to update.",
          result: { successfulEvents: [], failedEvents: [] },
        },
        { status: 200 },
      );
    }

    const CREATE_FULFILLMENT_EVENT = `
        mutation (
            $fulfillmentOrderId:ID!
            $status: FulfillmentEventStatus!
            $message: String
        ) {
        fulfillmentEventCreate (
            fulfillmentEvent: {
            fulfillmentId: $fulfillmentOrderId
            status: $status
            message: $message
            }
        ) {
            fulfillmentEvent {
            id
            status
            happenedAt
            }
            userErrors {
            field
            message
            }
        }
        }`;

    const successfulEvents = [];
    const failedEvents = [];

    // Your original sequential loop logic is preserved.
    for (const fulfillment of fulfillments) {
      try {
        const eventResponse = await fetch(shopify_api_url, {
          method: "POST",
          headers,
          body: JSON.stringify({
            query: CREATE_FULFILLMENT_EVENT,
            variables: { fulfillmentOrderId: fulfillment.id, status, message },
          }),
        });
        const eventJson = await eventResponse.json();

        const userErrors = eventJson.data?.fulfillmentEventCreate?.userErrors;
        if (userErrors && userErrors.length > 0) {
          logger.warn(
            `GraphQL UserError for fulfillment ${fulfillment.id}: ${JSON.stringify(userErrors)}`,
          );
          failedEvents.push({
            fulfillmentId: fulfillment.id,
            errors: userErrors,
          });
        } else if (eventJson.errors) {
          logger.error(
            `GraphQL Error for fulfillment ${fulfillment.id}: ${JSON.stringify(eventJson.errors)}`,
          );
          failedEvents.push({
            fulfillmentId: fulfillment.id,
            errors: eventJson.errors,
          });
        } else {
          successfulEvents.push(
            eventJson.data.fulfillmentEventCreate.fulfillmentEvent,
          );
        }
      } catch (err) {
        logger.error(
          `Network Error creating event for fulfillment ${fulfillment.id}: ${err.message}`,
        );
        failedEvents.push({
          fulfillmentId: fulfillment.id,
          errors: [
            {
              code: "NETWORK_ERROR",
              message: `Network request failed: ${err.message}`,
            },
          ],
        });
      }
    }

    // 4. Final Structured Response
    const responseMessage =
      failedEvents.length > 0
        ? `Process completed with ${successfulEvents.length} successes and ${failedEvents.length} failures.`
        : "All fulfillment events created successfully.";

    return createJsonResponse(
      {
        success: true,
        message: responseMessage,
        result: { successfulEvents, failedEvents },
      },
      { status: 200 },
    );
  } catch (error) {
    // 5. Catch-All for Unexpected Errors (e.g., request.json() fails)
    const errPayload = {
      code: "INTERNAL_SERVER_ERROR",
      message: error?.message || "An unexpected internal error occurred.",
      details: error?.stack || null,
    };
    logger.error(
      `Create Fulfillment Orders API - Unhandled Error - ${error?.stack || error.toString()}`,
    );
    return createJsonResponse(
      { success: false, error: errPayload },
      { status: 500 },
    );
  }
};
