import prisma from "../db.server";
import { authenticate } from "../shopify.server";
import { createOrder, signin } from "../services/API";
import { logger } from "../logger";

const createJsonResponse = (body, options) => {
  return new Response(JSON.stringify(body), {
    ...options,
    headers: { "Content-Type": "application/json", ...options?.headers },
  });
};

export const action = async ({ request }) => {
  let rawBody;
  try {
    // Read raw body
    rawBody = await request.text();

    const rawRequest = new Request(request.url, {
      method: request.method,
      headers: request.headers,
      body: rawBody,
    });

    // Auth the webhook
    const { shop } = await authenticate.webhook(rawRequest);

    let orderData;
    try {
      orderData = JSON.parse(rawBody);
    } catch (jsonError) {
      logger.error("Webhook - Invalid JSON payload", { error: jsonError });
      return createJsonResponse(
        {
          success: false,
          error: {
            code: "INVALID_JSON",
            message: "The webhook payload was not valid JSON.",
          },
        },
        { status: 400 },
      );
    }

    // Save order to DB
    try {
      await prisma.orders.create({
        data: {
          id: orderData.id.toString(),
          shop,
          admin_graphql_api_id: orderData.admin_graphql_api_id,
          order: orderData,
        },
      });
    } catch (dbError) {
      logger.error("Webhook - DB insert failed", {
        error: dbError,
        shop,
        orderId: orderData.id,
      });
      return createJsonResponse(
        {
          success: false,
          error: {
            code: "DATABASE_ERROR",
            message: "Failed to save order to the database.",
          },
        },
        { status: 500 },
      );
    }

    // First attempt to sync with external API
    let result;
    try {
      result = await createOrder([orderData], shop);
    } catch (apiError) {
      logger.error("Webhook - Create Order API call failed", {
        error: apiError,
      });
      return createJsonResponse(
        {
          success: false,
          error: {
            code: "API_ERROR",
            message: "Failed to sync order with the external API.",
          },
        },
        { status: 502 },
      );
    }

    // Handle 403 and retry once
    const isForbidden = (res) =>
      res?.results?.status_code === 403 ||
      (Array.isArray(res?.results) && res?.results[0]?.status_code === 403);

    if (isForbidden(result)) {
      logger.warn(
        "Webhook - Create Order - Unauthorized, retrying after signin.",
        { shop },
      );
      try {
        await signin(shop);
        result = await createOrder([orderData], shop);
        logger.info("Webhook - Create Order - 2nd try", result);

        if (isForbidden(result)) {
          logger.error(
            "Webhook - Create Order - Retry failed due to invalid credentials.",
            { shop },
          );
        }
      } catch (signinError) {
        logger.error("Webhook - Signin or Retry failed", {
          error: signinError,
          shop,
        });
        return createJsonResponse(
          {
            success: false,
            error: {
              code: "AUTHORIZATION_FAILED",
              message:
                "Could not authorize with the external API during retry.",
            },
          },
          { status: 401 },
        );
      }
    }

    return createJsonResponse(
      {
        success: true,
        message: "Webhook processed",
      },
      { status: 200 },
    );
  } catch (error) {
    logger.error("Webhook - Uncaught Exception", {
      error: error?.stack || error?.message || error, // line 142
      rawBody,
    });
    return createJsonResponse(
      {
        success: false,
        error: {
          code: "INTERNAL_ERROR",
          message: "An unexpected error occurred processing the webhook.",
          details: error?.message || "No error message available.",
        },
      },
      { status: 500 },
    );
  }
};
