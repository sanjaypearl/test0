import {
    Page,
    IndexTable,
    Text,
    Button,
    Card,
    Bleed,
    Frame,
    SkeletonBodyText,
    useIndexResourceState,
    Banner,
    BlockStack,
    List, // Import the List component
} from "@shopify/polaris";
import prisma from "../db.server";
import { authenticate } from "../shopify.server";
import { useLoaderData, useNavigate, useLocation, useFetcher } from "@remix-run/react";
import { useEffect, useState } from "react";
import { formatDate } from "../utils";
import { logger } from "../logger";
import { createOrder, signin } from "../services/API";

// --- Server Loader (MODIFIED) ---
export const loader = async ({ request }) => {
    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get("page") || "1", 10);
    const take = 25;
    const skip = (page - 1) * take;

    const { session } = await authenticate.admin(request);
    const { shop } = session;

    // Fetch orders and user authorization status in parallel for efficiency
    const [orders, totalCount, user] = await Promise.all([
        prisma.orders.findMany({
            where: { shop },
            skip,
            take,
            orderBy: { createdAt: "desc" },
        }),
        prisma.orders.count({ where: { shop } }),
        prisma.user.findFirst({
            where: { shop },
            select: { authorized: true }, // Only select the field we need
        })
    ]);

    // Pass authorization status to the client
    const isUserAuthorized = user?.authorized || false;

    return { orders, page, totalCount, isUserAuthorized };
};

export const action = async ({ request }) => {
    try {
        const { session } = await authenticate.admin(request);
        const { shop } = session;

        const formData = await request.formData();
        const selectedIds = JSON.parse(formData.get("selectedIds") || "[]");

        if (!Array.isArray(selectedIds) || selectedIds.length === 0) {
            return { success: false, summaryMessage: "No orders were selected." };
        }

        const user = await prisma.user.findFirst({ where: { shop } });
        if (!user?.authorized) {
            return { success: false, summaryMessage: "Authorization required. Please configure the app in the settings page." };
        }

        const ordersResult = await prisma.orders.findMany({
            where: { id: { in: selectedIds } },
            select: { order: true },
        });

        const orders = ordersResult.map((item) => item.order);

        if (orders && orders.length > 0) {
            let result = await createOrder(orders, shop);
            logger.info(`Sync Order 1st Try (Shop: ${shop}): ${JSON.stringify(result)}`);

            const needsRetry = Array.isArray(result?.results) && result.results.some(e => e.details?.status_code === 403);
            if (needsRetry) {
                logger.warn(`Token expired for shop ${shop}. Attempting to re-authenticate and retry.`);
                await signin(shop);
                result = await createOrder(orders, shop);
                logger.info(`Sync Order 2nd Try (Shop: ${shop}): ${JSON.stringify(result)}`);
            }

            // --- START: MODIFIED LOGIC ---
            
            let successCount = 0;
            let skippedCount = 0;
            let failedCount = 0;
            let detailedResults = []; // This will hold the per-order details

            if (Array.isArray(result?.results)) {
                // We need the original order numbers to display them in the UI
                const orderNumberMap = new Map(orders.map(o => [o.order_number.toString(), o.order_number]));
                
                for (const item of result.results) {
                    // The 'id' from createOrder result is the SHIPMENT_ORDER_NUMBER
                    const orderNumber = orderNumberMap.get(item.id);
                    
                    detailedResults.push({
                        orderNumber: orderNumber || item.id, // Fallback to id if not found
                        status: item.status,
                        message: item.message || "An unknown issue occurred."
                    });

                    switch (item?.status) {
                        case "success": successCount++; break;
                        case "skipped": skippedCount++; break;
                        case "failed":
                        case "error": failedCount++; break;
                        default: failedCount++; break;
                    }
                }
            } else {
                failedCount = selectedIds.length;
                logger.error(`API response for shop ${shop} was not in the expected format:`, result);
            }

            const messages = [];
            if (successCount > 0) messages.push(`${successCount} order${successCount > 1 ? 's' : ''} synched.`);
            if (failedCount > 0) messages.push(`${failedCount} failed.`);
            if (skippedCount > 0) messages.push(`${skippedCount} already existed or were skipped.`);

            return {
                success: failedCount === 0,
                summaryMessage: messages.join(' ') || "No orders were processed.",
                results: detailedResults, // Pass the detailed results to the client
            };

            // --- END: MODIFIED LOGIC ---

        } else {
            return {
                success: false,
                summaryMessage: "Selected orders could not be found. Please refresh and try again.",
            };
        }
    } catch (error) {
        logger.error("An unexpected error occurred in the sync action:", error);
        return {
            success: false,
            summaryMessage: "An unexpected server error occurred. Please try again later.",
        };
    }
};

// --- Client Component (MODIFIED) ---
export default function Order() {
    const fetcher = useFetcher();
    // Destructure the new isUserAuthorized prop
    const { orders, page, totalCount, isUserAuthorized } = useLoaderData();
    const navigate = useNavigate();
    const location = useLocation();

    const { selectedResources, allResourcesSelected, handleSelectionChange } = useIndexResourceState(orders);

 // --- START: MODIFIED STATE ---
    const [bannerContent, setBannerContent] = useState(null);
    const [bannerStatus, setBannerStatus] = useState("info");
    // This new state will hold the detailed results array
    const [syncResults, setSyncResults] = useState([]);
    // --- END: MODIFIED STATE ---
    const [loading, setLoading] = useState(false);

    const isSynching = fetcher.state === "submitting";
    const totalPages = Math.ceil(totalCount / 25);

   // --- START: MODIFIED EFFECT ---
    useEffect(() => {
        // Now handles the richer data object from the action
        if (fetcher.data) {
            setBannerContent(fetcher.data.summaryMessage || "An unexpected response was received.");
            setBannerStatus(fetcher.data.success ? "success" : "critical");
            // Store the detailed results if they exist and are not all successful
            if (Array.isArray(fetcher.data.results) && !fetcher.data.success) {
                setSyncResults(fetcher.data.results);
            }
        }
    }, [fetcher.data]);
    // --- END: MODIFIED EFFECT ---

    const handlePageChange = (direction) => {
        setLoading(true);
        const newPage = direction === "next" ? page + 1 : page - 1;
        navigate(`?page=${newPage}`);
    };

    useEffect(() => {
        setLoading(false);
    }, [location.search]);

    
    // This function will clear all banner-related state
    const handleBannerDismiss = () => {
        setBannerContent(null);
        setSyncResults([]);
    };

    const rowMarkup = loading ?
        Array.from({ length: 10 }).map((_, index) => (
            <IndexTable.Row id={`skeleton-${index}`} key={index} position={index}>
                {/* Skeleton cells */}
                <IndexTable.Cell><SkeletonBodyText lines={1} /></IndexTable.Cell>
                <IndexTable.Cell><SkeletonBodyText lines={1} /></IndexTable.Cell>
                <IndexTable.Cell><SkeletonBodyText lines={1} /></IndexTable.Cell>
                <IndexTable.Cell><SkeletonBodyText lines={1} /></IndexTable.Cell>
                <IndexTable.Cell><SkeletonBodyText lines={1} /></IndexTable.Cell>
                <IndexTable.Cell><SkeletonBodyText lines={1} /></IndexTable.Cell>
            </IndexTable.Row>
        )) :
        orders.map(({ id, order, createdAt, synched }, index) => (
            <IndexTable.Row id={id} key={id} position={index} selected={selectedResources.includes(id)}>
                <IndexTable.Cell><Text variant="bodyMd" fontWeight="bold" as="span">#{order.order_number}</Text></IndexTable.Cell>
                <IndexTable.Cell><Text variant="bodyMd" fontWeight="bold" as="span">{order.id.toString()}</Text></IndexTable.Cell>
                <IndexTable.Cell>{order?.billing_address?.name || order?.shipping_address?.name || order?.customer?.name || "N/A"}</IndexTable.Cell>
                <IndexTable.Cell>{order?.total_price}</IndexTable.Cell>
                <IndexTable.Cell>{formatDate(createdAt)}</IndexTable.Cell>
                <IndexTable.Cell>{synched ? "Yes" : "No"}</IndexTable.Cell>
            </IndexTable.Row>
        ));

    const resourceName = { singular: "order", plural: "orders" };

    // --- CONDITIONAL PRIMARY ACTION ---
    // This provides a much better user experience.
    const primaryActionMarkup = isUserAuthorized ? (
        <fetcher.Form method="post">
            <input type="hidden" name="selectedIds" value={JSON.stringify(selectedResources)} />
            <Button
                variant="primary"
                submit
                loading={isSynching}
                disabled={selectedResources.length === 0 || isSynching}
            >
                Sync Orders
            </Button>
        </fetcher.Form>
    ) : (
        <Button
            variant="primary"
            onClick={() => navigate("/app/settings")} // TODO: Adjust this path to your actual settings/authentication page
        >
            Authorize App to Sync
        </Button>
    );

    return (
        <Frame>
            <Page
                backAction={{ content: "Home", url: "/app" }}
                title="Webhook Orders"
                primaryAction={primaryActionMarkup} // Use the conditional markup here
            >
                <BlockStack gap="400">
                    {/* Display a banner if the user is not authorized */}
                    {!isUserAuthorized && (
                        <Banner title="Action Required" status="warning">
                            <p>
                                The application is not yet authorized to sync orders. Please complete the setup in the settings page.
                            </p>
                        </Banner>
                    )}

{/* --- START: MODIFIED BANNER RENDERING --- */}
                    {bannerContent && (
                        <Banner
                            title="Sync Status"
                            status={bannerStatus}
                            onDismiss={handleBannerDismiss}
                        >
                            <p>{bannerContent}</p>
                            {/* Conditionally render the list of details */}
                            {syncResults.length > 0 && (
                                <List type="bullet">
                                    {syncResults
                                        // Filter to show only items that didn't succeed
                                        .filter(res => res.status !== 'success')
                                        .map((result) => (
                                            <List.Item key={result.orderNumber}>
                                                <Text as="span" tone={result.status === 'skipped' ? 'subdued' : 'critical'}>
                                                    <strong>Order #{result.orderNumber}:</strong> {result.message}
                                                </Text>
                                            </List.Item>
                                        ))
                                    }
                                </List>
                            )}
                        </Banner>
                    )}
                    {/* --- END: MODIFIED BANNER RENDERING --- */}

                    <Card>
                        <Bleed marginBlock="400" marginInline="400">
                            <IndexTable
                                resourceName={resourceName}
                                itemCount={orders.length}
                                selectedItemsCount={allResourcesSelected ? 'All' : selectedResources.length}
                                onSelectionChange={handleSelectionChange}
                                selectable={isUserAuthorized} // Disable checkboxes if not authorized
                                headings={[
                                    { title: "Order" },
                                    { title: "Order Id" },
                                    { title: "Customer" },
                                    { title: "Total" },
                                    { title: "Created At" },
                                    { title: "Synced?" },
                                ]}
                                pagination={{
                                    hasPrevious: page > 1,
                                    hasNext: page < totalPages,
                                    onPrevious: () => handlePageChange("prev"),
                                    onNext: () => handlePageChange("next"),
                                }}
                            >
                                {rowMarkup}
                            </IndexTable>
                        </Bleed>
                    </Card>
                </BlockStack>
            </Page>
        </Frame>
    );
}