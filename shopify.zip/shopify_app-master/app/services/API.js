import axios from "axios";
import prisma from "../db.server";
import { logger } from "../logger";
import { formatDate } from "../utils";

export const signin = async (shop, username = undefined, password = undefined) => {
    try {

        const existingUser = await prisma.user.findFirst({
            where: {
                shop
            }
        })

        logger.info(`Username: ${username} - Password - ${password} - Existing User: ${JSON.stringify(existingUser)}`)


        if (!username && !password && !existingUser) {
            logger.error(`API - Sign in - No user exists for the shop ${shop}`)
            return {
                data: {
                    status: false,
                    message: "No user exists for this shop."
                }
            }
        }

        const userName = username || existingUser.username
        const userPass = password || existingUser.password

        const result = await axios.post(
            `${process.env.API_URL}/authToken`,
            {
                username: userName ,
                password: userPass
            }
        )

        //${JSON.stringify(result?.data)}
        logger.info(`API - Sign In -  - status: ${result?.status}`)

        if (!result?.data?.token) {
            return {
                data: {
                    status: false,
                    message: "Invalid credentails."
                }
            }
        }

        let user = await prisma.user.upsert({
            where: { shop },
            update: { username: userName, password: userPass, token: result?.data?.token, authorized: true },
            create: { shop, username: userName, password: userPass, token: result?.data?.token, authorized: true },
        });

        return { user, result };
    } catch (error) {
        console.error(error)
        logger.error(`API - Sign In - ${JSON.stringify(error)}`)
        return { success: false, message: "server error, please try again later or contact your admin." }
    }
}

export const createOrder = async (orders, shop) => {
    try {
        const user = await prisma.user.findFirst({
            where: { shop: shop }
        });

        if (!user) {
            logger.error(`User not found for shop ${shop}`);
            return { success: false, message: "User Not Found." };
        }

        const promises = [];

        for (const orderData of orders) {
            const orderNumber = orderData?.order_number.toString();
            const shipmentItems = [];

            if(Array.isArray(orderData?.line_items)){
            for (const i of orderData?.line_items) { 
                let IGST_PERCENTAGE = 0;
                let CGST_PERCENTAGE = 0;
                let SGST_PERCENTAGE = 0;

                if(Array.isArray(i.tax_lines)){
                for (const tax of i.tax_lines) {
                    switch (tax.title) {
                        case "IGST": IGST_PERCENTAGE = tax.rate; break;
                        case "CGST": CGST_PERCENTAGE = tax.rate; break; // 93
                        case "SGST": SGST_PERCENTAGE = tax.rate; break;
                    }
                }
                }

                shipmentItems.push({
                    DESCRIPTION: i.title,
                    QUANTITY: Number(i?.quantity),
                    ITEM_PRICE: Number(i?.price) || Number(orderData?.total_price), // 102
                    SKU_CODE: i?.sku,
                    HSN_CODE: "",
                    IGST_PERCENTAGE,
                    CGST_PERCENTAGE,
                    SGST_PERCENTAGE
                });
            }
            }

            

            const payload = {
                "*SHIPMENT_ORDER_NUMBER": orderNumber,
                "*SHIPMENT_INVOICE_CODE": "",
                "*SHIPMENT_ORDER_DATE": formatDate(orderData?.created_at),
                "*SHIPMENT_WEIGHT": `${orderData?.total_weight}`,
                "SHIPMENT_LENGTH": "1",
                "SHIPMENT_HEIGHT": "1",
                "SHIPMENT_BREADTH": "1",
                "*SHIPMENT_ITEMS": shipmentItems,
                "ORDER_DATA": orderData,
                "*CUSTOMER_NAME":
                orderData?.billing_address?.name ||
                (orderData?.billing_address?.first_name && orderData?.billing_address?.last_name
                    ? `${orderData.billing_address.first_name} ${orderData.billing_address.last_name}`
                    : orderData?.shipping_address?.first_name && orderData?.shipping_address?.last_name
                    ? `${orderData.shipping_address.first_name} ${orderData.shipping_address.last_name}`
                    : undefined), 
                "*CUSTOMER_EMAIL":
                    orderData?.contact_email || orderData?.customer?.email || orderData?.email, // 132
                "*CUSTOMER_PHONE":
                    orderData?.billing_address?.phone || orderData?.shipping_address?.phone || "9999999999", // 134
                "*CUSTOMER_ADDRESS1": orderData?.shipping_address?.address1,
                "*CUSTOMER_ADDRESS2": orderData?.shipping_address?.address2,
                "*CUSTOMER_PINCODE": orderData?.shipping_address?.zip,
                CUSTOMER_CITY: orderData?.shipping_address?.city,
                CUSTOMER_STATE: orderData?.shipping_address?.province,
                CUSTOMER_COUNTRY: orderData?.shipping_address?.country,
                "*PAYMENT_MODE": orderData?.financial_status,
                "*TOTAL_AMOUNT": orderData?.total_price,
                "*COLLECTABLE_AMOUNT": orderData?.total_outstanding
            };

            const promise = axios
                .post(
                    `${process.env.API_URL}/order_allocation/shopify/create_order`,
                    payload,
                    {
                        headers: {
                            Authorization: `Bearer ${user.token}`
                        }
                    }
                )
                .then(async (result) => {
                    const responseData =  result?.data || {};

                    logger.info(`API Response for order ${orderNumber}: ${JSON.stringify(responseData)}`);
                    
                    // Case 1: API confirms successful creation
                    if (responseData?.status_code === 200) {
                        logger.info(`Successfully created order ${orderNumber}.`);
                        await prisma.orders.update({
                            where: { id: orderData?.id.toString() },
                            data: { synched: true }
                        });
                        return { id: orderNumber, status: "success", message: "Order created successfully." };
                    }
                    
                    // Case 2: API reports the order already exists. This is not a failure.
                    // We treat it as a success for our purposes and ensure our DB is marked as synched.
                    if (responseData?.status_code === 400 && responseData?.data?.message?.includes("Order Already Exist")) {
                        logger.warn(`Skipped order ${orderNumber}: it already exists in the target system.`);
                        await prisma.orders.update({
                            where: { id: orderData?.id.toString() },
                            data: { synched: true }
                        });
                        return { id: orderNumber, status: "skipped", message: "Order already exists." };
                    }

                    // Case 3: Any other business logic failure from the API (e.g., validation error).
                    const errorMessage = responseData?.data?.message || "Unknown business logic failure.";
                    logger.error(`Failed to create order ${orderNumber}. Reason: ${JSON.stringify(errorMessage)}`);
                    return { id: orderNumber, status: "failed", message: errorMessage, details: responseData };

                })
                .catch((error) => {
                    // Case 4: Network error or non-2xx HTTP status from axios
                    const status_code = error?.response?.status;
                    const error_message = error?.response?.data?.message || error?.response?.data || error.message;
                    logger.error(`API Error for order ${orderNumber} [${status_code}]: ${JSON.stringify(error_message)}`);
                    return {
                        id: orderNumber,
                        status: "error",
                        message: `API request failed with status ${status_code}.`,
                        details: error_message
                    };
                });

            promises.push(promise);
        }

        const results = await Promise.all(promises);

        const isOverallSuccess = results.every(
            (res) => res.status === 'success' || res.status === 'skipped'
        );
        
        if (!isOverallSuccess) {
            logger.error(`One or more orders failed to sync. Results: ${JSON.stringify(results)}`);
        }

        return { success: isOverallSuccess, results };

    } catch (err) {
        logger.error(`A critical error occurred in createOrder function: ${err.message}`, { stack: err.stack }); // 217
        return { success: false, message: "Server error, please try again later or contact admin." };// 218
    }
};
